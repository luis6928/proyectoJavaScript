document.addEventListener("DOMContentLoaded", function() {
    const carrusel = document.querySelector(".carrusel");
    const imagenes = carrusel.querySelectorAll("img");
    const botonAnterior = document.getElementById("anterior");
    const botonSiguiente = document.getElementById("siguiente");
    let indiceActual = 0;
  
    function mostrarImagen(indice) {
      imagenes.forEach((imagen, i) => {
        if (i === indice) {
          imagen.style.display = "block";
        } else {
          imagen.style.display = "none";
        }
      });
    }

    
  
    mostrarImagen(indiceActual);
  
    botonAnterior.addEventListener("click", function() {
      indiceActual--;
      if (indiceActual < 0) {
        indiceActual = imagenes.length - 1;
      }
      mostrarImagen(indiceActual);
    });
  
    botonSiguiente.addEventListener("click", function() {
      indiceActual++;
      if (indiceActual >= imagenes.length) {
        indiceActual = 0;
      }
      mostrarImagen(indiceActual);
    });
  
    setInterval(() => {
      indiceActual++;
      if (indiceActual >= imagenes.length) {
        indiceActual = 0;
      }
      mostrarImagen(indiceActual);
    }, 3000);
  });
  